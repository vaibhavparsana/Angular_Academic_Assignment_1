export class Books 
{ sBookName: string;
    sAuthor: string;
    sBookGenre: string;
    sYearPublished: number;
}