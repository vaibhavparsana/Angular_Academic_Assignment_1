import { Books } from '../../app/bookInfo';

export const MyBooks: Books[] = [{
    sBookName: "Merchants of Doubt",
    sAuthor: "Naomi Oreskes‎, ‎Erik M. Conway",
    sBookGenre: "Documentary",
    sYearPublished: 2010 
},{
    sBookName: "Blue Ocean Shift: Beyond Competing",
    sAuthor: "W. Chan Kim, Renee Mauborgne ",
    sBookGenre: "Business Management",
    sYearPublished: 2017
},{
    sBookName: "When: The Scientific Secrets of Perfect Timing",
    sAuthor: "Daniel H. Pink ",
    sBookGenre: "Non-fiction",
    sYearPublished: 2018
},{
    sBookName: "Experience on Demand",
    sAuthor: "Jeremy Bailenson",
    sBookGenre: "Virtual reality",
    sYearPublished: 2018
}];