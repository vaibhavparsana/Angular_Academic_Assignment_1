export class Parsanav 
{ sid: number;
    sname: string;
    scampus: string;
    slogin: string;
    stitle: string;
}